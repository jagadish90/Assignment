import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RestService {
  apiurl = "https://api.github.com/search/users?q=varun1505"
  apiurl2 = "https://api.github.com/users/"
  constructor(private http: HttpClient) { }
  getprofile(): Observable<any> {
    return this.http.get(this.apiurl, { responseType: 'json' })
  }
  getfulldetails(id: any): Observable<any> {
    console.log('hi')
    return this.http.get(this.apiurl2 + id + '/repos', { responseType: 'json' })
  }
  getname() {
    return this.http.get(this.apiurl2, { responseType: 'json' })
  }

}

