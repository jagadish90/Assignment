import { Component, OnInit, OnChanges } from '@angular/core';
import { RestService } from '../rest.service';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  data1: any[] = [];
  alphasort: any
  constructor(private ser: RestService) { }
  uid: any
  sortByKey(array, key) {
    return array.sort(function (a, b) {
      var x = a[key]; var y = b[key];
      return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
  }
  sortByKey1(array, key) {
    return array.sort(function (a, b) {
      var x = a[key]; var y = b[key];
      return ((x > y) ? -1 : ((x < y) ? 1 : 0));
    });
  }

  data() {
    // var b:any[]=[]
    this.ser.getprofile().subscribe((data) => {
      // this.data1=data.items
      this.data1 = data.items

    })
    return this.data1
  }
  sorting(a: number) {
    var b: any
    alert(a)
    if (a == 1) {
      console.log(this.data().sort())
     this.gitdata=this.data().sort()
    }
    //
    if (a == 2) {
      b = this.data()
      console.log(b.reverse())
      this.gitdata=b.reverse()
      alert(JSON.stringify(this.gitdata));
    }
    if (a == 3) {

      console.log(this.sortByKey(this.data(), 'score'))
      this.gitdata = this.sortByKey(this.data(), 'score')
    }
    if (a == 4) {

      console.log(this.sortByKey1(this.data(), 'score'))
      this.gitdata = this.sortByKey1(this.data(), 'score')
    }
  }
  gitdata: any
  gitdata1: any[]
  moredetails: any
  public isCollapsed: boolean = true;
  getmoredetails(id: any) {
    alert(id)
    this.ser.getfulldetails(id).subscribe((data) => {
      this.moredetails = data
      this.uid = this.moredetails[0].owner.login
      alert(this.uid)
      console.log(this.moredetails)
    })
  }


  ngOnInit() {
    var dt: any;
    this.data()
    this.ser.getprofile().subscribe((data) => {
      this.gitdata = data.items
      //console.log(this.gitdata)


    })
    // this.ser.getfulldetails().subscribe((data) => {
    //   this.gitdata1 = data
    //     console.log(this.gitdata1)
    // })
  }


 

}
